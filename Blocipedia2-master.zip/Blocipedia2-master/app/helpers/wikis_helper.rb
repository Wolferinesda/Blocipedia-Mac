module WikisHelper
end
