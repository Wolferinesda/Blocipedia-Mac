FactoryBot.define do
  factory :collaborator do

  end
end
